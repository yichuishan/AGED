"""Regression checks for the archived diagnostic, not benchmark accuracy tests."""

import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

import numpy as np
import pytest
import torch
from torch.nn import functional as F

from aged import data as D
from aged.config import Config
from aged.losses import GeodesicLoss
from aged.runtime import build_model
from aged.train import critic_inputs, run_training


SCRIPT = Path(__file__).resolve().parents[2] / "docs/integration-checks/5a48f7d/grad_balance.py"


@pytest.fixture
def diagnostic():
    spec = importlib.util.spec_from_file_location("gradient_diagnostic", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize("objective", ["minimax", "non_saturating"])
@pytest.mark.parametrize("variant", ["full", "geodesic", "fidelity", "continuity"])
def test_gradient_probe_matches_math_and_preserves_model(motion_export, diagnostic, objective, variant):
    config = Config(actions=["walking", "eating"], hidden_dim=8, critic_hidden_dim=8,
                    batch_size=2, device="cpu", variant=variant, adversarial_objective=objective)
    norm = D.fit_normalisation(motion_export, D.TRAIN_SUBJECTS, config.actions)
    model = build_model(config, norm)
    batch = D.WindowDataset(motion_export, norm, ["S1"], config.actions, length=2)[0]
    observed, target, action = (value[None] for value in batch)
    geometry = GeodesicLoss(norm, config.geodesic_reduction)
    # Compute the reference directly from logits, independent of loss dispatch.
    prediction = model.predict(observed, action, config.prediction_length)
    reference = prediction.new_zeros(())
    for _, critic, fake, _ in critic_inputs(model, observed, prediction, target):
        logits = critic.logits(fake)
        reference = reference + (-F.softplus(logits).mean() if objective == "minimax"
                                 else F.softplus(-logits).mean())
    parameters = list(model.predictor.parameters())
    if reference.requires_grad:
        gradients = torch.autograd.grad(config.lambda_adv * reference, parameters)
        expected_norm = float(torch.cat([g.flatten() for g in gradients]).norm())
    else:
        expected_norm = 0.0
    expected_loss = float(reference.detach())
    before = {key: value.clone() for key, value in model.state_dict().items()}
    flags = [p.requires_grad for p in model.parameters()]
    for parameter in model.parameters():
        parameter.grad = torch.full_like(parameter, 0.125)
    actual = diagnostic.measure_batch(model, geometry, (observed, target, action), config)
    assert actual["adv"] == pytest.approx(expected_loss, abs=1e-7)
    assert actual["g_adv"] == pytest.approx(expected_norm, rel=1e-5, abs=1e-7)
    assert np.isfinite(list(actual.values())).all()
    if variant == "geodesic":
        assert actual["ratio"] == 0 and actual["cosine"] == 0
    if variant == "full":
        assert "fidelity_cosine" in actual and "continuity_cosine" in actual
        assert -1.000001 <= actual["critics_cosine"] <= 1.000001
    assert flags == [p.requires_grad for p in model.parameters()]
    for key, value in model.state_dict().items():
        torch.testing.assert_close(value, before[key], rtol=0, atol=0)
    for parameter in model.parameters():
        torch.testing.assert_close(parameter.grad, torch.full_like(parameter, 0.125), rtol=0, atol=0)


@pytest.mark.parametrize("variant", ["full", "geodesic"])
def test_gradient_probe_cli_reads_existing_checkpoint_without_s5(motion_export, tmp_path, variant):
    config = Config(actions=["walking", "eating"], hidden_dim=8, critic_hidden_dim=8,
                    batch_size=2, epochs=1, steps_per_epoch=1, validation_windows=2,
                    val_subject="S11", device="cpu", variant=variant,
                    adversarial_objective="non_saturating")
    checkpoint = run_training(config, motion_export, tmp_path / "run with spaces")
    checksum = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    # The diagnostic must also work when neither S5 nor held-out S11 exists.
    train_only = tmp_path / "training subjects only"
    for subject in D.TRAIN_SUBJECTS:
        if subject != config.val_subject:
            shutil.copytree(motion_export / subject, train_only / subject)
    result = subprocess.run([sys.executable, str(SCRIPT), str(checkpoint),
                             "--root", str(train_only), "--device", "cpu", "--batches", "2"],
                            capture_output=True, text=True, timeout=90)
    assert result.returncode == 0, result.stdout + result.stderr
    actual = json.loads(result.stdout)
    assert actual["diagnostic_version"] == 2
    assert actual["adversarial_objective"] == "non_saturating"
    assert actual["device"] == "cpu" and actual["batches"] == 2
    assert np.isfinite(list(actual["mean"].values())).all()
    assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == checksum

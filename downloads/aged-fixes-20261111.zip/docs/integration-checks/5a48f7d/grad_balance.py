"""How much the adversarial term moves the predictor, compared with the geodesic loss.

For one checkpoint (or the step-0 initialisation of its config), on a fixed set of
training batches drawn from the six training subjects, computes per batch:
  g_rec = d(reconstruction)/d(predictor params)
  g_adv = d(lambda_adv * configured adversarial term)/d(predictor params) (critics frozen)
and reports their norms, the ratio |g_adv|/|g_rec|, their cosine, and the critic accuracies.
Also reports each critic's gradient separately. Ratios are pre-clip norm ratios,
NOT fractions of an actual SGD or Adam update: direction, clipping and optimizer
state matter. No optimizer step is performed and no checkpoint is written.
Diagnostic only; nothing here selects a model. S5 is not used.

Run from the repository root in its Python environment:
  python docs/integration-checks/5a48f7d/grad_balance.py CHECKPOINT.pt --device cuda
Optional: --init --batches 50 --root data/h36m --device cpu --threads 1
Prints one JSON line. Existing aggregate keys are retained.
"""

import argparse
import json

import numpy as np
import torch
from torch.utils.data import DataLoader

from aged import critics as C
from aged import data as D
from aged.config import Config
from aged.losses import GeodesicLoss
from aged.runtime import build_model, load_checkpoint, pick_device, seed_everything
from aged.train import critic_inputs, critic_parameters, reconstruction


def _flat_gradient(loss, parameters):
    if not loss.requires_grad:
        return torch.cat([torch.zeros_like(p).flatten() for p in parameters])
    gradients = torch.autograd.grad(loss, parameters, retain_graph=True, allow_unused=True)
    return torch.cat([(g if g is not None else torch.zeros_like(p)).flatten()
                      for p, g in zip(parameters, gradients)])


def _cosine(left, right):
    denominator = left.norm() * right.norm()
    return float(torch.dot(left, right) / denominator.clamp_min(1e-12))


def measure_batch(model, geometry, batch, config):
    """Read-only diagnostic; parameter values and .grad buffers stay untouched."""
    parameters = [p for p in model.predictor.parameters() if p.requires_grad]
    critics = critic_parameters(model)
    original_flags = [p.requires_grad for p in critics]
    for parameter in critics:
        parameter.requires_grad_(False)
    try:
        observed, target, action = batch
        predicted = model.predict(observed, action, config.prediction_length)
        rec = reconstruction(config, geometry, predicted, target)
        g_rec = _flat_gradient(rec, parameters)
        g_adv = torch.zeros_like(g_rec)
        adv = predicted.new_zeros(())
        per_critic = {}
        gradients = {}
        objective = (C.generator_loss if config.adversarial_objective == "minimax"
                     else C.generator_loss_non_saturating)
        for name, critic, fake, real in critic_inputs(model, observed, predicted, target):
            term = objective(critic, fake)
            gradient = _flat_gradient(config.lambda_adv * term, parameters)
            gradients[name] = gradient
            g_adv = g_adv + gradient
            adv = adv + term.detach()
            with torch.no_grad():
                accuracy = C._critic_terms(critic, real.detach(), fake.detach())[2]
            per_critic.update({
                name + "_accuracy": accuracy,
                name + "_g_adv": float(gradient.norm()),
                name + "_ratio": float(gradient.norm() / g_rec.norm().clamp_min(1e-12)),
                name + "_cosine": _cosine(g_rec, gradient),
            })
        n_rec, n_adv = float(g_rec.norm()), float(g_adv.norm())
        result = {"rec": float(rec.detach()), "adv": float(adv),
                  "g_rec": n_rec, "g_adv": n_adv,
                  "ratio": n_adv / max(n_rec, 1e-12),
                  "cosine": _cosine(g_rec, g_adv), **per_critic}
        if len(gradients) == 2:
            result["critics_cosine"] = _cosine(gradients["fidelity"], gradients["continuity"])
        return result
    finally:
        for parameter, original in zip(critics, original_flags):
            parameter.requires_grad_(original)


def _positive_int(value):
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return number


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint")
    parser.add_argument("--init", action="store_true", help="use the step-0 initialisation of this config")
    parser.add_argument("--batches", type=_positive_int, default=50)
    parser.add_argument("--root", default="data/h36m")
    parser.add_argument("--device", default="auto", help="auto, cpu, cuda, cuda:0, or mps")
    parser.add_argument("--threads", type=_positive_int, default=1)
    args = parser.parse_args()
    saved = load_checkpoint(args.checkpoint)
    config = Config(**saved["config"])
    norm = D.Normalisation.from_dict(saved["normalisation"])
    device = pick_device(args.device)
    torch.set_num_threads(args.threads)
    seed_everything(config.seed)
    model = build_model(config, norm)
    if not args.init:
        model.load_state_dict(saved["model"])
    model.to(device).train()
    geometry = GeodesicLoss(norm, config.geodesic_reduction).to(device)
    subjects = [s for s in D.TRAIN_SUBJECTS if s != config.val_subject]
    dataset = D.WindowDataset(args.root, norm, subjects, config.actions, config.observed_length,
                              config.prediction_length, args.batches * config.batch_size, 4242,
                              config.sampling_strategy, config.minimum_start)
    loader = DataLoader(dataset, batch_size=config.batch_size, shuffle=False)
    rows = [measure_batch(model, geometry, tuple(t.to(device) for t in batch), config)
            for batch in loader]
    summary = {key: float(np.mean([row[key] for row in rows])) for key in rows[0]}
    summary["ratio_median"] = float(np.median([row["ratio"] for row in rows]))
    print(json.dumps({"checkpoint": args.checkpoint, "init": args.init, "epoch": 0 if args.init else saved["epoch"],
                      "prediction_length": config.prediction_length, "lambda_adv": config.lambda_adv,
                      "batches": len(rows), "batch_size": config.batch_size,
                      "adversarial_objective": config.adversarial_objective, "device": str(device),
                      "diagnostic_version": 2,
                      "interpretation": "pre-clip gradients; not optimizer update fractions",
                      "mean": summary}, allow_nan=False))


if __name__ == "__main__":
    main()
